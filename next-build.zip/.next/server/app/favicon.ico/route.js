var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__827bc745._.js")
R.c("server/chunks/f7813_next_dist_esm_build_templates_app-route_f8ae94e8.js")
R.c("server/chunks/[root-of-the-server]__aeaa9263._.js")
R.c("server/chunks/f7813_next_2a236fa2._.js")
R.m(15934)
R.m(91828)
module.exports=R.m(91828).exports
