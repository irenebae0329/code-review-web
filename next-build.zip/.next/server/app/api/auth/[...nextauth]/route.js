var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__59fda386._.js")
R.c("server/chunks/_3f3e9310._.js")
R.c("server/chunks/[root-of-the-server]__aeaa9263._.js")
R.m(43433)
R.m(131)
module.exports=R.m(131).exports
