var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/nextjs/projects/[id]/commits/route.js")
R.c("server/chunks/[root-of-the-server]__039d0525._.js")
R.c("server/chunks/[root-of-the-server]__aeaa9263._.js")
R.c("server/chunks/f7813_next_2a236fa2._.js")
R.m(40279)
R.m(3387)
module.exports=R.m(3387).exports
