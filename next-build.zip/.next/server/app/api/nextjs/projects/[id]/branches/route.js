var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/nextjs/projects/[id]/branches/route.js")
R.c("server/chunks/[root-of-the-server]__fbed69c9._.js")
R.c("server/chunks/f7813_next_2a236fa2._.js")
R.c("server/chunks/[root-of-the-server]__aeaa9263._.js")
R.c("server/chunks/_80893460._.js")
R.m(10840)
R.m(76985)
module.exports=R.m(76985).exports
