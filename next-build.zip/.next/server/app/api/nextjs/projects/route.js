var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/nextjs/projects/route.js")
R.c("server/chunks/[root-of-the-server]__d347d469._.js")
R.c("server/chunks/f7813_next_2a236fa2._.js")
R.c("server/chunks/[root-of-the-server]__7ee158d2._.js")
R.c("server/chunks/[root-of-the-server]__aeaa9263._.js")
R.m(41842)
R.m(29984)
module.exports=R.m(29984).exports
