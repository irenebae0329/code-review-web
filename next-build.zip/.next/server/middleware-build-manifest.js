globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/07c5976035b17e6e.js",
      "static/chunks/3b59b6d29f5db165.js",
      "static/chunks/turbopack-4f06a920df192ff7.js"
    ],
    "/_error": [
      "static/chunks/8d07a75d85f150f6.js",
      "static/chunks/3b59b6d29f5db165.js",
      "static/chunks/turbopack-614e9cdd483a077c.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/997881dd04209b7e.js",
    "static/chunks/2cdc1c929e91d6b5.js",
    "static/chunks/0fdbfe6041a9dd3f.js",
    "static/chunks/577cddf74fd6bc0b.js",
    "static/chunks/f2d08e05888188d4.js",
    "static/chunks/turbopack-918c0e6753e80599.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];