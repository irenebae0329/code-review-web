globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/07c5976035b17e6e.js",
      "static/chunks/9f81faa6e6f92c15.js",
      "static/chunks/turbopack-52eeafb38a3f41be.js"
    ],
    "/_error": [
      "static/chunks/8d07a75d85f150f6.js",
      "static/chunks/9f81faa6e6f92c15.js",
      "static/chunks/turbopack-a1c900dc21c5c2c2.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/2ddb733044421c58.js",
    "static/chunks/2cdc1c929e91d6b5.js",
    "static/chunks/0fdbfe6041a9dd3f.js",
    "static/chunks/b1357aaa8e63eeee.js",
    "static/chunks/f2d08e05888188d4.js",
    "static/chunks/turbopack-760ed98a40c93eda.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];