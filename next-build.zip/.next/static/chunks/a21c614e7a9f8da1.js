__turbopack_load_page_chunks__("/_app", [
  "static/chunks/07c5976035b17e6e.js",
  "static/chunks/3b59b6d29f5db165.js",
  "static/chunks/turbopack-4f06a920df192ff7.js"
])
