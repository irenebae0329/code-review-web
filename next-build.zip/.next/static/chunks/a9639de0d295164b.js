__turbopack_load_page_chunks__("/_error", [
  "static/chunks/8d07a75d85f150f6.js",
  "static/chunks/9f81faa6e6f92c15.js",
  "static/chunks/turbopack-a1c900dc21c5c2c2.js"
])
