__turbopack_load_page_chunks__("/_app", [
  "static/chunks/07c5976035b17e6e.js",
  "static/chunks/9f81faa6e6f92c15.js",
  "static/chunks/turbopack-52eeafb38a3f41be.js"
])
