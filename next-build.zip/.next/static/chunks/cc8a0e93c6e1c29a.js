__turbopack_load_page_chunks__("/_error", [
  "static/chunks/8d07a75d85f150f6.js",
  "static/chunks/3b59b6d29f5db165.js",
  "static/chunks/turbopack-614e9cdd483a077c.js"
])
